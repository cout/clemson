#include <algorithm>
#include <assert.h>
#include "spantree.h"

// next_tree (nextree) produces the next spanning tree in a graph with
// the given ordered edge set.  It returns the number of edges in the
// next tree, or 0 if there is no next tree.
int Spantree::next_tree() {
	int i, j, k;
	int x, y;
	bool backtrack;

	k = f.size();
	if(k == graph.num_nodes - 1) {
		j = k;
		i = f[k-1] + 1;
		f.pop_back();
	} else if(k > 0) {
		j = k + 1;
		i = f[k-1] + 1;
	} else {
		j = 1;
		i = 0;
	}

	// We are not backtracking initially
	backtrack = false;

	while(j < graph.num_nodes) {

		// This code is a bit difficult to understand at a first glance.  We
		// traverse the ctr structure, and if we don't find an intersection
		// between at least one element of each list in the ctr structure and
		// f, then we will set backtrack.
		vector<list<int> >::iterator it;
		for(it = graph.ctr[i].begin(); it != graph.ctr[i].end(); it++) {
			list<int>::iterator it2;
			if(it->begin() == it->end()) continue;
			backtrack = true;
			for(it2 = it->begin(); it2 != it->end(); it2++) {
				int s = *it2;
				if(find(f.begin(), f.end(), s) != f.end()) {
					backtrack = false;
				}
			}
			if(backtrack) break;
		}

		// If (num edges in spanning tree) - (index of the edge)
		// + 1 is less than (number of nodes in graph) -
		// (stage of building the subtree) then set
		// backtrack
		if((graph.num_edges - i - 0) < (graph.num_nodes - j))
			backtrack = true;

		if(backtrack) {
			j--;
			if(j == 0) return j;
			i = f[j-1] + 1;
			while(f.size() != (unsigned)(j-1)) f.pop_back();
			backtrack = false;

		} else {
			x = g[j-1][graph.edges[i][0]];
			y = g[j-1][graph.edges[i][1]];

			if(x == y) {
				i++;
			} else {
				f.push_back(i);

				for(int v = 0; v < graph.num_nodes; v++) {
					if(g[j-1][v] == y) {
						g[j][v] = x;
					} else {
						g[j][v] = g[j-1][v];
					}
				}
				j++;
				i++;
			}
		}
	}

	return j;
}

// gbuild produces the next nxn component status array for a given edge
// list and edge-index selector.
void Spantree::gbuild() {
	int v, j;
	int x, y;

	vector<int> emptyvect;
	for(int j = 0; j < graph.num_nodes; j++) {
		g.push_back(emptyvect);
		g[j].reserve(graph.num_nodes);
		for(v = 0; v < graph.num_nodes; v++) g[j].push_back(-1);
		g[0][j] = j;
	}

	for(j = 1; (unsigned)j < f.size(); j++) {
		x = g[j-1][graph.edges[f[j]][0]];
		y = g[j-1][graph.edges[f[j]][1]];
		for(v = 0; v < graph.num_nodes; v++) {
			if(g[j-1][v] == y) {
				g[j][v] = x;
			} else {
				g[j][v] = g[j-1][v];
			}
		}
	}
}

