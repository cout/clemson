#include <GL/gl.h>
#include <GL/glx.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "glc.h"

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE !FALSE
#endif

#define MAX_GLC_CONTEXTS 256
#define MAX_GLC_FONTS 16

#define GLC_EXTENSIONS_STRING ""
#define GLC_RELEASE_STRING "0.2 Mesa-GLC 0.1"
#define GLC_VENDOR_STRING "Paul Brannan"
#define GLC_VERSION_MAJOR_NUMBER 0
#define GLC_VERSION_MINOR_NUMBER 2

enum GLCStyles {
	GLC_STYLE_NORMAL,
	GLC_STYLE_BOLD,
	GLC_STYLE_ITALIC,
	GLC_STYLE_BOLD_ITALIC,
	NUM_GLC_STYLES
};
#define GLC_NOT_A_FONT NUM_GLC_STYLES

typedef struct {
	GLboolean isFont;
	GLCchar *name;
	GLCchar *xfontname;
	Font xfont;
} GLCfont;

typedef struct {
	GLboolean isContext;
	Display *display;
	GLint font_list[MAX_GLC_FONTS+2];
	GLCfont fonts[MAX_GLC_FONTS+1][NUM_GLC_STYLES];
	GLint font_faces[MAX_GLC_FONTS+1];
	GLint num_fonts;
	GLfloat bitmap_matrix[4];
	GLvoid* data_pointer;
	GLint current_font_list[MAX_GLC_FONTS];
	GLint num_current_fonts;
	GLint list_base;
} GLCcontext;

static int glcContextList[MAX_GLC_CONTEXTS+2];
static GLCcontext glcContexts[MAX_GLC_CONTEXTS+1];
static int numGlcContexts = 0;
static int currentGlcContext = 0;
static GLboolean isFirstCall = TRUE;
static GLCenum last_error = GLC_NONE;
static GLCcontext *g = NULL;

GLint glcGenContext() {
	GLCcontext *c;
	int i, j;

	/* If this is the first call, initialize our data */
	if(numGlcContexts==0) {
		memset(glcContextList, 0, sizeof(glcContextList));
		memset(glcContexts, 0, sizeof(glcContexts));
	}
	isFirstCall = FALSE;

	/* Find context that is not in use */
	for(j = 1; j < MAX_GLC_CONTEXTS; j++)
		if(!glcContexts[j].isContext) break;
	if(j == MAX_GLC_CONTEXTS) return 0;

	/* Add this context to the list */
	glcContextList[numGlcContexts++] = j;
	glcContextList[numGlcContexts] = 0;

	/* Initialize this context */
	c = &glcContexts[j];
	c->isContext = TRUE;
	c->display = (Display*)glXGetCurrentDisplay();
	c->bitmap_matrix[0] = 1.0;
	c->bitmap_matrix[1] = 0.0;
	c->bitmap_matrix[2] = 0.0;
	c->bitmap_matrix[3] = 1.0;
	last_error = GLC_NONE;
	c->data_pointer = 0;
	c->num_fonts = 0;
	c->list_base = glGenLists(256);

	/* Load a default font */
	memset(c->font_list, 0, sizeof(c->font_list));
	c->fonts[0][GLC_STYLE_NORMAL].xfont = XLoadFont(c->display, "variable");
	c->fonts[0][GLC_STYLE_NORMAL].name = strdup("base");
	c->fonts[0][GLC_STYLE_NORMAL].xfontname = strdup("variable");
	c->fonts[0][GLC_STYLE_NORMAL].isFont = TRUE;
	glXUseXFont(c->fonts[0][GLC_STYLE_NORMAL].xfont, 1, 256, c->list_base);
	for(i = 1; i < NUM_GLC_STYLES; i++) c->fonts[0][i].isFont = FALSE;

	return j;
}

void glcContext(GLint c){
	if(!glcIsContext(c)) {
		last_error = GLC_PARAMETER_ERROR;
	} else {
		currentGlcContext = c;
		g = &glcContexts[currentGlcContext];
	}
}

void glcDeleteContext(GLint c) {
	int i, j;

	if(!glcIsContext(c)) {
		last_error = GLC_PARAMETER_ERROR;
		return;
	}

	/* Find this context in the list */
	for(j = 0; glcContextList[j] != 0; j++)
		if(glcContextList[j] == c) break;

	/* Delete all fonts in this context */
	for(i = glcContexts[c].num_fonts-1; i > 0; i--)
		glcDeleteFont(i);

	/* Delete the GL lists we are using */
	glDeleteLists(g->list_base, 256);

	/* Mark this context as unused */
	glcContexts[j].isContext = FALSE;

	/* Delete this context from the list */
	for(; glcContextList[j] != 0; j++)
		glcContextList[j] = glcContextList[j + 1];
}

GLint* glcGetAllContexts() {
	int *list = malloc(sizeof(glcContextList));
	memcpy(list, glcContextList, sizeof(glcContextList));
	return list;
}

GLint glcGetCurrentContext() {
	return currentGlcContext;
}

GLboolean glcIsContext(GLint context) {
	if(context > MAX_GLC_CONTEXTS || context < 0) {
		last_error = GLC_PARAMETER_ERROR;
		return FALSE;
	}
	return glcContexts[context].isContext;
}

void glcRenderChar(char c) {
	int i;
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	i = g->current_font_list[0];
	glCallList(g->list_base + c);
}

void glcRenderString(const GLCchar *s) {
	glcRenderCountedString(strlen(s), s);
}

void glcRenderCountedString(GLint count, const GLCchar* s) {
	int i;
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	i = g->current_font_list[0];
	glListBase(g->list_base);
	glCallLists(count, GL_UNSIGNED_BYTE, s);
}

void glcFont(GLint font) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	if(font != g->current_font_list[0]) {
#ifdef DEBUG
		fprintf(stderr, "Switching to font %d\n", font);
#endif
		glXUseXFont(g->fonts[font][g->font_faces[font]].xfont, 0, 256, g->list_base);
	}
	g->num_current_fonts = 1;
	g->current_font_list[0] = font;
	g->current_font_list[1] = 0;
}

GLboolean glcIsFont(GLint font) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return FALSE;
	}
	return g->fonts[font][GLC_STYLE_NORMAL].isFont;
}

void glcDeleteFont(GLint font) {
	int j;

	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	if(g->font_list[font] == 0) {
		last_error = GLC_PARAMETER_ERROR;
		return;
	}

	/* Delete this font */
	for(j = 0; j < NUM_GLC_STYLES; j++) {
		if(g->fonts[font][j].isFont) {
			if(g->fonts[font][j].name) free(g->fonts[font][j].name);
			if(g->fonts[font][j].xfontname) free(g->fonts[font][j].name);
			g->fonts[font][j].isFont = FALSE;
		}
	}

	/* Find this font in the font list */
	for(j = 0; g->font_list[j] != 0; j++)
		if(g->font_list[j] == font) break;

	/* Delete this font from the list */
	for(; g->font_list[j] != 0; j++)
		g->font_list[j] = g->font_list[j+1];
}

void glcFontFace(GLint fontnum, const char *style) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
}

GLint glcNewFontFromFamily(GLint fontnum, const char *s) {
	char **xfontlist;
	int fontlen = strlen(s);
	char *fontname = malloc(fontlen+7);
	int num_fonts;
	XFontStruct *xfontinfo;
	int height;
	int font, our_font[NUM_GLC_STYLES];
	int font_distance, our_font_distance[NUM_GLC_STYLES];
	int j;

#ifdef DEBUG
	fprintf(stderr, "glcNewFontFromFamily(%d, \"%s\")\n", fontnum, s);
#endif

	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return GLC_NONE;
	}
	fontname[0] = '*';
	for(j = 0; j <= fontlen; j++) fontname[j+1] = tolower(s[j]);
	strcat(fontname, "*");
	xfontlist = XListFontsWithInfo(g->display, fontname, 1000, &num_fonts,
		&xfontinfo);
	if(num_fonts == 0) return 0;

	/* We prefer a font of size 24 -- we will take the closest */
	for(j = 0; j < NUM_GLC_STYLES; j++) {
		our_font[j] = 0;
		our_font_distance[j] = INT_MAX;
	}
	for(font = 0; font < num_fonts; font++) {
		height = xfontinfo[font].ascent + xfontinfo[font].descent;
		font_distance = (height-24)*(height-24);
		if(strstr(xfontlist[font], "medium-r")) {
			if(font_distance < our_font_distance[GLC_STYLE_NORMAL]) {
				our_font_distance[GLC_STYLE_NORMAL] = font_distance;
				our_font[GLC_STYLE_NORMAL] = font;
			}
		} else if(strstr(xfontlist[font], "bold-r")) {
			if(font_distance < our_font_distance[GLC_STYLE_BOLD]) {
				our_font_distance[GLC_STYLE_BOLD] = font_distance;
				our_font[GLC_STYLE_BOLD] = font;
			}
		} else if(strstr(xfontlist[font], "medium-i")) {
			if(font_distance < our_font_distance[GLC_STYLE_ITALIC]) {
				our_font_distance[GLC_STYLE_ITALIC] = font_distance;
				our_font[GLC_STYLE_ITALIC] = font;
			}
		} else if(strstr(xfontlist[font], "bold-i")) {
			if(font_distance < our_font_distance[GLC_STYLE_BOLD_ITALIC]) {
				our_font_distance[GLC_STYLE_BOLD_ITALIC] = font_distance;
				our_font[GLC_STYLE_BOLD_ITALIC] = font;
			}
		}
	}

	for(j = 0; j < NUM_GLC_STYLES; j++) {
		if(our_font_distance[j] != INT_MAX) {
			if(g->fonts[fontnum][j].isFont) glcDeleteFont(fontnum);
			g->fonts[fontnum][j].xfont = XLoadFont(g->display, xfontlist[our_font[j]]);
			g->fonts[fontnum][j].isFont = TRUE;
			g->fonts[fontnum][j].name = strdup(s);
			g->fonts[fontnum][j].xfontname = strdup(xfontlist[our_font[j]]);
#ifdef DEBUG
			fprintf(stderr, "Using font %s.\n", xfontlist[our_font[j]]);
#endif
		} else {
			g->fonts[fontnum][j].isFont = FALSE;
		}
	}


	XFreeFontInfo(xfontlist, xfontinfo, num_fonts);
	return fontnum;
}

void glcGenFontID() {
	int j;

	/* Find a font that is not in use */
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	for(j = 1; j < MAX_GLC_FONTS; j++)
		if(!g->fonts[j][GLC_STYLE_NORMAL].isFont) break;
	if(j == MAX_GLC_FONTS) return;

	/* Add this font to the list */
	g->font_list[g->num_fonts++] = j;
	g->font_list[g->num_fonts] = 0;

	/* Initialize the font */
	g->fonts[j][GLC_STYLE_NORMAL].isFont = TRUE;
}

const GLCchar* glcGetc(GLCenum attrib) { 
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return NULL;
	}
	switch(attrib) {
		case GLC_EXTENSIONS: return GLC_EXTENSIONS_STRING;
		case GLC_RELEASE: return GLC_RELEASE_STRING;
		case GLC_VENDOR: return GLC_VENDOR_STRING;
		default: return NULL;
	}
}

GLfloat glcGetf(GLCenum attrib) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return 0.0;
	}
	switch(attrib) {
		case GLC_RESOLUTION: return 0.0;
		default: return 0.0;
	}
}

void glcGetfv(GLCenum attrib, GLfloat *vec) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	switch(attrib) {
		case GLC_BITMAP_MATRIX:
			memcpy(vec, g->bitmap_matrix, sizeof(g->bitmap_matrix));
			return;
		default: return;
	}
}

GLint glcGeti(GLCenum attrib) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return GLC_NONE;
	}
	switch(attrib) {
		case GLC_CATALOG_COUNT: return 0;
		case GLC_CURRENT_FONT_COUNT: return 0;
		case GLC_FONT_COUNT: return 0;
		case GLC_LIST_OBJECT_COUNT: return 0;
		case GLC_MASTER_COUNT: return 0;
		case GLC_MEASURED_CHAR_COUNT: return 0;
		case GLC_RENDER_STYLE: return GLC_BITMAP;
		case GLC_REPLACEMENT_CODE: return 0;
		case GLC_STRING_TYPE: return GLC_UCS1;
		case GLC_TEXTURE_OBJECT_COUNT: return 0;
		case GLC_VERSION_MAJOR: return GLC_VERSION_MAJOR_NUMBER;
		case GLC_VERSION_MINOR: return GLC_VERSION_MINOR_NUMBER;
		default: return 0;
	}
}

GLboolean glcIsEnabled(GLCenum attrib) { 
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return FALSE;
	}
	return 0;
}

GLCenum glcGetError() { 
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return GLC_NONE;
	}
	return last_error;
}

void glcDataPointer(GLvoid *pointer) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return;
	}
	g->data_pointer = pointer;
}

GLvoid* glcGetPointer(GLCenum attrib) {
	if(currentGlcContext == 0) {
		last_error = GLC_STATE_ERROR;
		return NULL;
	}
	switch(attrib) {
		case GLC_DATA_POINTER: return g->data_pointer;
		default: return NULL;
	}
}

/* Unsupported functions */
void glcCallbackFunc(GLCenum opcode, GLCfunc func) {}
GLCfunc glGetCallbackFunc(GLCenum opcode) { return NULL; }
void glcDeleteGLObjects() {}
void glcDisable(GLCenum attrib) {}
const GLCchar* glcGetListc(GLCenum attrib, GLint index) { return NULL; }
GLint glcGetListi(GLCenum attrib, GLint index) { return 0; }
void glcStringType(GLCenum type) {}
void glcAppendCatalog(const GLCchar* catalog) {}
const GLCchar* glcGetMasterListc(GLint master, GLCenum attrib, GLint index) { return NULL; }
const GLCchar* glcGetMasterMap(GLint master, GLint code) { return NULL; }
const GLCchar glcGetMasterc(GLint master, GLCenum attrib) { return 0; }
GLint glcGetMasteri(GLint master, GLCenum attrib) { return 0; }
void glcPrependCatalog(const GLCchar* catalog) {}
void glcRemoveCatalog(GLint index) {}
void glcAppendFont(GLint font) {}
void glcFontMap(GLint font, GLint code, const GLCchar *name) {}
const GLCchar* glcGetFontFace(GLint font) { return NULL; }
const GLCchar* glcGetFontListc(GLint font, GLCenum attrib, GLint index) { return NULL; }
const GLCchar* glcGetFontMap(GLint font, GLint code) { return NULL; }
const GLCchar* glcGetFontc(GLint font, GLCenum attrib) { return NULL; }
GLint glcGetFonti(GLint font, GLCenum attrib) { return 0; }
GLint glcNewFontFromMaster(GLint font, GLint master) { return 0; }
void glcLoadIdentity() {}
void glcLoadMatrix(const GLfloat *matrix) {}
void glcMultMatrix(const GLfloat *matrix) {}
void glcRotate(GLfloat angle) {}
void glcScale(GLfloat x, GLfloat y) {}
void glcRenderStyle(GLCenum style) {}
void glcReplacementCode(GLint code) {}
void glcResolution(GLfloat res) {}
GLfloat* glcGetCharMetric(GLint code, GLCenum metric, GLfloat* vec) { return NULL; }
GLfloat* glcGetMaxCharMetric(GLCenum metric, GLfloat* vec) { return NULL; }
GLfloat* glcGetStringCharMetric(GLint index, GLCenum metric, GLfloat *vec) { return NULL; }
GLfloat* glcGetStringMetric(GLCenum metric, GLfloat *vec) { return NULL; }
GLint glcMeasureCountedString(GLboolean chars, GLint count, const GLCchar *s) { return 0; }
GLint glcMeasureString(GLboolean chars, const GLCchar *s) { return 0; }

