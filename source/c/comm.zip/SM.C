	if(color_flag==1) ScreenMemory=MK_FP(0xb800,0);
	else ScreenMemory=MK_FP(0xb000,0);
