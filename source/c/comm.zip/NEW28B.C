#include <stdio.h>
#include <conio.h>

extern void SET28();

main () {
	printf("Hello, world!\n");
	SET28();
	printf("Hello again!\n");
	getch();
}
