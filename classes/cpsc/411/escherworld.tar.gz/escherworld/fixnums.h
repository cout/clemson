#ifndef FIXNUMS_H
#define FIXNUMS_H

unsigned int fixint(unsigned int i);
float fixfloat(float f);

#endif
