#ifndef CRATER_H
#define CRATER_H

void init_craters();
void draw_craters();

#endif
