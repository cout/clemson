#ifndef BOX_H
#define BOX_H

void draw_box(float l, float w, float h);
void init_box();

#endif

