#ifndef LIGHTING_H
#define LIGHTING_H

void do_lighting();

#endif

