#ifndef NPR_DRAW_H
#define NPR_DRAW_H

#include "md2.h"

void npr_draw_model(md2_model_t model, int currentFrame);

#endif
