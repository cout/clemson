#ifndef OURSTRING_H
#define OURSTRING_H

#ifndef WIN32
int strcmpi(const char *s1, const char *s2);
#endif

#endif
